package Swathi01;

class Constructor{  
	
	
	
	Constructor(){
		
		displayNandri()	;		
		
		
		}  
	 
	private void displayNandri() {
		// TODO Auto-generated method stub
		System.out.println("CoronaIndia Stats is created");
	}

	public static CoronaIndiaStats getIndiaStats(){
		CoronaIndiaStats tamilnadu= new CoronaIndiaStats();
		tamilnadu.setStateName("TAMILNADU");
		tamilnadu.setTotalCasesCount(new Integer(1566));
		tamilnadu.setTotalRecovered(new Integer(500));
		return tamilnadu;
	}               
		
	}  
	  