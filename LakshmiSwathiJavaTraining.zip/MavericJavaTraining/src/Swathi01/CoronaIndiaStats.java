package Swathi01;

public class CoronaIndiaStats {
	
	private String stateName;
	private Integer totalCasesCount;
	private Integer totalRecovered;
	
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public Integer getTotalCasesCount() {
		return totalCasesCount;
	}
	public void setTotalCasesCount(Integer totalCasesCount) {
		this.totalCasesCount = totalCasesCount;
	}
	public Integer getTotalRecovered() {
		return totalRecovered;
	}
	public void setTotalRecovered(Integer totalRecovered) {
		this.totalRecovered = totalRecovered;
	}
	

}
