package Swathi01;

public class Subtracion {

	
	public static void main(String[] args) {
	 int a=123;
	 int b=123;
	 int c=a-b;
	 
	 System.out.print(c);

	}

}
