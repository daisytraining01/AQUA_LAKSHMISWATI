package Swathi01;

public class Palindrome {
	
	public static void main(String[] args){
		
		
		String test= "TEST";
		String test2= "TET";
	
		System.out.println(ispalindrome(test));
		System.out.println(ispalindrome(test2));
		
	}
	
	static boolean ispalindrome(String input){
		boolean test=false;
		
		return input.equals(new StringBuilder(input).reverse().toString());
	}

}
