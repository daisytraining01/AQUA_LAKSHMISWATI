package Swathi01;

public class StringManipulations {
	
	
	
	
	public static void main(String[] test){
		
		String a = "REST ASSURED";
		String b= "Test";
		String c= "REST ASSURED";
		
		System.out.println("edited string "+ a.replaceAll("ST", ""));
		System.out.println("string Compare "+ a.equals(b)+" "+a.equals(c));
		
		
			
		
	}

}
