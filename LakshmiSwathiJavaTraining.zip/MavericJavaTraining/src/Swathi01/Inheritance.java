package Swathi01;

public class Inheritance extends Constructor{
	
	public static void main(String[] methodArgs){
		
		Constructor test= new Constructor();
		CoronaIndiaStats tamil=getIndiaStats();
		
		System.out.println("State "+tamil.getStateName());
		System.out.println("cases count "+tamil.getTotalCasesCount());
		System.out.println("recovered count "+tamil.getTotalRecovered());
		
		
	}
	

}
