package Swathi01;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RemovedupHasSet {
	
	public static void main(String[] testargs){
		
		List<String> names= new ArrayList<String>(); 
		names.add("1");
		names.add("1");
		names.add("2");
		names.add("2");
		names.add("3");
		names.add("3");
		
		Set<String> removedups= new HashSet<String>(names);
		
		for(String test :removedups ){
			
			System.out.println(test);
		}
		
		
		
	}

}
