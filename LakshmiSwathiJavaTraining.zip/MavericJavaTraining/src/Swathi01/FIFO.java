package Swathi01;

import java.util.ArrayList;
import java.util.List;

public class FIFO {
	
	public static void main(String[] lastprograme){
		
		List<String> names= new ArrayList<String>(); 
		names.add("1");
		names.add("1");
		names.add("2");
		names.add("2");
		names.add("3");
		names.add("3");
		
		System.out.println(names.get(0));
		
	}

}
